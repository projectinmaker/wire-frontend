export { default } from "@/components/erp/purchasing/index"
