export { default } from "@/components/erp/cash-bank/index"
