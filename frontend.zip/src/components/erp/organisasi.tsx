export { default } from '@/components/erp/organisasi/index';
